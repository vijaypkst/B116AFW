fruits=['Apple','Mango','Orange','Grapes',"Banana"]

print(fruits[-1:-6:-1])