a=['hi','bye']
print(a)

v=a[0] #reading 1st element from list , storing it in v
print(v)

a[0]='tata' #writing / modify the 1st element of the element
print(a)