a='''hi bhanu
h r u
had food?'''

#why tripple quote?--->
print(a)