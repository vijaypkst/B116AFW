a=123
print(a)

a='abc'
print(a) # abc

a="abc"
print(a) # abc

a='''abc'''
print(a) # abc

a="'abc'"
print(a)

a='"abc"'
print(a)

a="'''abc'''" #print sting along with tripple quotes
print(a)