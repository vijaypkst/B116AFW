#delcare variable but dont store anything
a=None
print(a)

b=10 #i want to remove the value
b=None
print(b)
