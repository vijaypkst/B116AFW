mylist=[10,'bhanu',True,23.56]
print(type(mylist))
print(len(mylist))
print(mylist)
print(mylist[0])
print(mylist[1])
print(mylist[2])
print(mylist[3])
print(mylist[4])

