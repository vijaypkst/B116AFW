fruits=['Apple','Mango','Orange']
print(type(fruits))
print(len(fruits))
print(fruits[0])
print(fruits[1])
print(fruits[2])
print(fruits)