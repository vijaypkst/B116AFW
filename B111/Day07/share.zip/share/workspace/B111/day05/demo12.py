fruits=['Apple','Mango','Orange','Grapes',"Banana"]

print(fruits) #all elements
print(fruits[0]) #1st element
print(fruits[0:2]) #from 0 and before 2
print(fruits[0:3]) # 0 1 2 (except 3)
print(fruits[2:5]) #2 3 4
print(fruits[2:]) #start from 2 till the end
print(fruits[0:4:1])
print(fruits[0:5:2])

print(fruits[:4]) #0 1 2 3