a=['cat','dog','cow']
print(a[0])
print(a[-3])

print(a[1])
print(a[-2])

print(a[2])
print(a[-1])
