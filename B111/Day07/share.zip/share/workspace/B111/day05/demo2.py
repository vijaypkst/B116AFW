#string --> group of char with in quotes

a='sachin'
print(a,type(a))

b="bhanu"
print(b,type(b))

c='''ravi'''
print(c,type(c))