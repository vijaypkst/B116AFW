fruits=['Apple','Mango','Orange']
print(fruits[0])
print(fruits[1])
print(fruits[2])
# print(fruits[3]) # index error--> out  of range
print('----')
print(fruits[-1])
print(fruits[-2])
print(fruits[-3])
print(fruits[-4])# index error--> out  of range
