a=10
a=20
a=30
print(a)
x=10
y=20
z=30
print(x,y,z)
#a var can hold only one value at a time
b=[10,20,30]
print(b)

print(type(a))
print(type(b))
