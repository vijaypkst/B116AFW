a=['is it',True,2]

#diff ways of printing 2
print(a[2],a[-1])

#diff ways of printing 'is it'
print(a[0],a[-3])

#diff ways of printing  True
print(a[1],a[-2])