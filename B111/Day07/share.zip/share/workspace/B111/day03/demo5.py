#this is comment , we can write any notes....

a=10  #store 10 in a
b=20
print(a+b)

# x=10
# y=20
# z=30
# p=50