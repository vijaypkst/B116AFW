a=10
a=20
a=30
print(a)