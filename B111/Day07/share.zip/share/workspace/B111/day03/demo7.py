from keyword import kwlist

print(kwlist)

print(len(kwlist))
