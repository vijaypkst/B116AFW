i=10
j=20
print('the i value is',i,'and the j value is',j)

