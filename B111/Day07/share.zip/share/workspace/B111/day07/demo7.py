a=[10,20,30]
b=[40,50,60]

print(a)
a.append(35) #do not use append/insert to merge 2 lists
print(a)

a.append(b)
print(a)

print(a[0])

print(a[4])

print(a[4][0])