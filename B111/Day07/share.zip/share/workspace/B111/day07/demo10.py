a=[10,3,12,89,54]
print(a)
a.reverse()
print(a)
a.reverse()
print(a)

a=[10,'Hi',True,3.45,3j]
print(a)
a.reverse()
print(a)
