a=[10,20,30,40]
print(a)
a.append(50)
print(a)

a.insert(0,5)
print(a)

a.insert(5,60)
print(a)

a.insert(15,70)
print(a)

a.insert(-1,67)
print(a)

a.insert(-10,3)
print(a)