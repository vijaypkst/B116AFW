#list --> group of elements
a=[10,3,20,45]
print(a)
print(a[1])
print(a[-1::-1])
print(len(a))
print(id(a))
print(min(a))
print(max(a))
print(sum(a))
print(sorted(a))
print(a)
print(sorted(a,reverse=True))