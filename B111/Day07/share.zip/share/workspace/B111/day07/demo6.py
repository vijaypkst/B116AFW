a=[10,20,30,40]
print(a)
print(len(a)) #4

a.clear() #deletes all the list elements
print(a)
print(len(a)) #0

b=[]
b.clear()  #even if the list is empty we dont get any error
