a=[10,20]
b=[30,40]
a.append(b)
print(a)

a=[10,20]
b=[30,40]
a.extend(b)
print(a)