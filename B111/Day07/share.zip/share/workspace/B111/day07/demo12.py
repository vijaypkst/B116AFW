a=[10,3,12]
b=a
print(id(a))
print(id(b))

print(a)
print(b)

a.sort()
print(a)
print(b)

a=[10,3,12]
b=a.copy()
print(id(a))
print(id(b))

print(a)
print(b)

a.sort()
print(a)
print(b)
