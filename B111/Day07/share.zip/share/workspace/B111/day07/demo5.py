a=[10,20,30,40]
print(a)

x=a.remove(10)  #delete the element '10' & return nothing
print(a)
print(x)


a=[10,20,30,40]
print(a)

x=a.pop(0)  #delete the 1st element '10' & return it (store it in x)
print(a)
print(x)