a=[10,3,12,89,54]
print(a) #10,3,12,89,54
a.sort()
print(a) #3 10 12 54 89
a.reverse()
print(a) #89 54 12 10 3
a.sort(reverse=True)
print(a)