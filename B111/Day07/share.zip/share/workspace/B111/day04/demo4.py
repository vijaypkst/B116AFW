a=10
res=type(a)
print(res)


a=10
print(type(a)) #output of inner function will be input for outer function


# a=23.56
# print(a)
#
# a='bhanu'
# print(a)
#
# a=True
# print(a)
#
# a='True'
# print(a)