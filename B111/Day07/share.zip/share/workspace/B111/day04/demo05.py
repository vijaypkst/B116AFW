#code optimization
# a=10
# print(a)

print(10)

i=10
j=20
k=i+j
print(k)

i=10
j=20
print(i+j)

i=10
print(i+20)

print(10+20)


