print('bhanu','prakash')
print('bhanu'+'prakash')
a=10
print(a, type(a))

a=10.34
print(a, type(a))

a=3j
print(a, type(a))

a=10+5j
print(a, type(a))

c=10
b=c+1j
print(type(b))