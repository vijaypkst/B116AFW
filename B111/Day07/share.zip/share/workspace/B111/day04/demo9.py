#create a varibale but dont want store any value

a=None
print(a,type(a))


a='None'
print(a,type(a))

a=True
print(a,type(a))

a='True'
print(a,type(a))