a=100
b=type(a)
print(b)


a=100
print(type(a))