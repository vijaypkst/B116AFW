from keyword import kwlist

a=100 #a variable , 100 value
a=200
print(a) # print the function

print(kwlist)
count=len(kwlist)
print(count)