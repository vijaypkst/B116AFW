a=0
print(123)
print('a')
print(a)

#a is the name of the variable--> identifier

