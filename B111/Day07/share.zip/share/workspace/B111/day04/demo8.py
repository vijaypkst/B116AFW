a=True
print(a,type(a))

a=False
print(a,type(a))
