a=[7,2,31,4,50]
print(a)
print(type(a))
print(len(a))
print(id(a))

print(max(a))
print(min(a))
print(sum(a))

b=['a','b','c']
print(b)
print(type(b))
print(len(b))
print(id(b))
print(max(b)) # biggest string based on ASCII value
print(min(b))# smallest string based on ASCII value
print(sum(b)) #error