a=[7,2,31,4,50]
b=sorted(a)
c=sorted(a,reverse=True)
print(a)
print(b)
print(c)

a=['Banana','Mango','Apple']
b=sorted(a)
c=sorted(a,reverse=True)
print(a)
print(b)
print(c)

a=[10,'Apple',True]
b=sorted(a)
print(a)
print(b)