a=[10,20,30]
print(a)#[10,20,30]
x=a[0] #read 1st element from list and store it in x variable
print(x)
a[0]=100 #writing the element into list
print(a) #[100,20,30]

