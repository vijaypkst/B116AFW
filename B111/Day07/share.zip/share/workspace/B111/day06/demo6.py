list1=[10,20,30]
print(list1)

list1.append(40)
print(list1)

list1.append(50)
print(list1)

list1.insert(1,70)
print(list1)

list1.insert(-1,80)
print(list1)

list1.insert(0,90)
print(list1)