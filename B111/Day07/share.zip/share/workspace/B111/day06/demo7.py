list1=[10,20]
print(list1)
count=len(list1)
#add element at end without using append
list1.insert(count,30)
print(list1)

list1.insert(-9,68)
print(list1)