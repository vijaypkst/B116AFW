a=[10,20,30,40,50]
print(a) #all elements
print(a[0]) #1st element
print(a[-1]) #last element
print(a[0:3:1])        #1st 3 elements
print(a[:3:1])
print(a[:3:])
print(a[::])
print(a[-1:-3:-1])
print(a[-1::-1])
print(a[0:5:2])                #10 30 50
print(a[0::2])
print(a[::2])
print(a[::-2])
#print 20 30 40
print(a[1:4])

